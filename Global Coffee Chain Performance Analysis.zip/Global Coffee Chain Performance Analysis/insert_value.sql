-- 1. Insert countries data
INSERT INTO countries (country_id, country_name, continent, gdp_per_capita, population)
VALUES 
(1, 'United States', 'North America', 65000, 331000000),
(2, 'United Kingdom', 'Europe', 42000, 67000000),
(3, 'Canada', 'North America', 46000, 38000000),
(4, 'Australia', 'Oceania', 52000, 25600000),
(5, 'Japan', 'Asia', 40000, 126000000),
(6, 'Germany', 'Europe', 48000, 83000000),
(7, 'France', 'Europe', 43000, 67000000),
(8, 'Italy', 'Europe', 35000, 60000000),
(9, 'Brazil', 'South America', 9000, 213000000),
(10, 'Mexico', 'North America', 10000, 126000000),
(11, 'South Korea', 'Asia', 35000, 52000000),
(12, 'Spain', 'Europe', 30000, 47000000),
(13, 'United Arab Emirates', 'Asia', 43000, 10000000),
(14, 'Singapore', 'Asia', 65000, 5700000),
(15, 'China', 'Asia', 11000, 1400000000);

SELECT * FROM countries;


-- Stores Data

INSERT INTO stores (store_id, country_id, city, address, opening_date, square_footage, has_drive_thru, is_24_hours)
VALUES
(1, 1, 'New York', '100 Main Street', '2018-01-01', 1200, FALSE, FALSE),
(2, 1, 'Los Angeles', '101 Main Street', '2018-01-31', 1500, TRUE, FALSE),
(3, 1, 'Chicago', '102 Main Street', '2018-03-02', 900, FALSE, FALSE),
(4, 1, 'Houston', '103 Main Street', '2018-04-01', 1100, TRUE, FALSE),
(5, 1, 'Miami', '104 Main Street', '2018-05-01', 1300, FALSE, TRUE),
(6, 2, 'London', '105 Main Street', '2018-05-31', 1800, FALSE, FALSE),
(7, 2, 'Manchester', '106 Main Street', '2018-06-30', 950, TRUE, FALSE),
(8, 2, 'Birmingham', '107 Main Street', '2018-07-30', 800, FALSE, FALSE),
(9, 2, 'Liverpool', '108 Main Street', '2018-08-29', 1200, FALSE, FALSE),
(10, 3, 'Toronto', '109 Main Street', '2018-09-28', 1400, TRUE, FALSE),
(11, 3, 'Vancouver', '110 Main Street', '2018-10-28', 1600, FALSE, TRUE),
(12, 3, 'Montreal', '111 Main Street', '2018-11-27', 1000, FALSE, FALSE),
(13, 4, 'Sydney', '112 Main Street', '2018-12-27', 1700, TRUE, FALSE),
(14, 4, 'Melbourne', '113 Main Street', '2019-01-26', 850, FALSE, FALSE),
(15, 4, 'Brisbane', '114 Main Street', '2019-02-25', 1200, FALSE, FALSE),
(16, 5, 'Tokyo', '115 Main Street', '2019-03-27', 1900, TRUE, FALSE),
(17, 5, 'Osaka', '116 Main Street', '2019-04-26', 1100, FALSE, FALSE),
(18, 5, 'Kyoto', '117 Main Street', '2019-05-26', 1300, FALSE, TRUE),
(19, 6, 'Major City 1', '118 Main Street', '2019-06-25', 1400, FALSE, FALSE),
(20, 7, 'Major City 2', '119 Main Street', '2019-07-25', 900, TRUE, FALSE),
(21, 8, 'Major City 3', '120 Main Street', '2019-08-24', 1100, FALSE, FALSE),
(22, 9, 'Major City 4', '121 Main Street', '2019-09-23', 1500, FALSE, FALSE),
(23, 10, 'Major City 5', '122 Main Street', '2019-10-23', 1200, TRUE, FALSE),
(24, 11, 'Major City 6', '123 Main Street', '2019-11-22', 1000, FALSE, TRUE),
(25, 12, 'Major City 7', '124 Main Street', '2019-12-22', 1300, FALSE, FALSE),
(26, 13, 'Major City 8', '125 Main Street', '2020-01-21', 1600, TRUE, FALSE),
(27, 14, 'Major City 9', '126 Main Street', '2020-02-20', 950, FALSE, FALSE),
(28, 15, 'Major City 10', '127 Main Street', '2020-03-21', 1200, FALSE, FALSE),
(29, 1, 'New York', '128 Main Street', '2020-04-20', 1400, TRUE, FALSE),
(30, 2, 'London', '129 Main Street', '2020-05-20', 1100, FALSE, TRUE);

SELECT * FROM stores;

-- 3. Insert menu items
INSERT INTO menu_items (item_id, category, item_name, description, base_price, cost_to_make, is_seasonal)
VALUES
-- Coffees
(1, 'Coffee', 'Espresso', 'Strong black coffee', 2.50, 0.60, FALSE),
(2, 'Coffee', 'Americano', 'Espresso with hot water', 3.00, 0.75, FALSE),
(3, 'Coffee', 'Latte', 'Espresso with steamed milk', 4.50, 1.20, FALSE),
(4, 'Coffee', 'Cappuccino', 'Espresso with foamed milk', 4.50, 1.25, FALSE),
(5, 'Coffee', 'Mocha', 'Chocolate espresso with milk', 5.00, 1.50, FALSE),
(6, 'Coffee', 'Iced Coffee', 'Chilled coffee with ice', 4.00, 1.00, FALSE),
(7, 'Coffee', 'Pumpkin Spice Latte', 'Seasonal favorite', 5.50, 1.75, TRUE),
(8, 'Coffee', 'Peppermint Mocha', 'Holiday special', 5.50, 1.80, TRUE),

-- Teas
(9, 'Tea', 'Green Tea', 'Traditional green tea', 3.00, 0.50, FALSE),
(10, 'Tea', 'Black Tea', 'English breakfast tea', 3.00, 0.50, FALSE),
(11, 'Tea', 'Chai Latte', 'Spiced tea with milk', 4.50, 1.00, FALSE),
(12, 'Tea', 'Iced Tea', 'Chilled tea with ice', 3.50, 0.75, FALSE),

-- Food
(13, 'Food', 'Croissant', 'Buttery French pastry', 3.50, 1.00, FALSE),
(14, 'Food', 'Blueberry Muffin', 'Fresh baked muffin', 3.75, 1.10, FALSE),
(15, 'Food', 'Chocolate Chip Cookie', 'Classic cookie', 2.50, 0.60, FALSE),
(16, 'Food', 'Avocado Toast', 'Sourdough with avocado', 7.50, 2.50, FALSE),
(17, 'Food', 'Breakfast Sandwich', 'Egg and cheese on croissant', 6.50, 2.00, FALSE),
(18, 'Food', 'Cinnamon Roll', 'Seasonal favorite', 4.50, 1.25, TRUE),

-- Other
(19, 'Other', 'Bottled Water', '500ml spring water', 2.00, 0.30, FALSE),
(20, 'Other', 'Orange Juice', 'Fresh squeezed juice', 4.00, 1.25, FALSE);

SELECT * FROM menu_items;


--  Insert promotions
INSERT INTO promotions (promotion_id, promotion_name, description, start_date, end_date, discount_percentage, applicable_items)
VALUES
(1, 'Summer Coffee Special', 'Discount on all iced drinks', '2023-06-01', '2023-08-31', 15.00, 'Coffee'),
(2, 'Happy Hour', 'Afternoon discount', '2023-01-01', '2023-12-31', 10.00, 'All'),
(3, 'Loyalty Reward', 'Special for gold members', '2023-01-01', '2023-12-31', 20.00, 'All'),
(4, 'Holiday Bundle', 'Buy one get one free on seasonal items', '2023-11-20', '2023-12-31', 50.00, 'Seasonal'),
(5, 'Breakfast Combo', 'Coffee + food item discount', '2023-01-01', '2023-12-31', 12.00, 'Coffee,Food');

SELECT * FROM promotions;


-- Insert customers (200 customers)
INSERT INTO customers (customer_id, first_name, last_name, email, join_date, loyalty_tier, birthday)
SELECT 
    n,
    CASE (n % 10)
        WHEN 0 THEN 'Emily' WHEN 1 THEN 'James' WHEN 2 THEN 'Sarah' 
        WHEN 3 THEN 'Michael' WHEN 4 THEN 'Jessica' WHEN 5 THEN 'David'
        WHEN 6 THEN 'Jennifer' WHEN 7 THEN 'Christopher' WHEN 8 THEN 'Lisa' ELSE 'Daniel'
    END,
    CASE (n % 10)
        WHEN 0 THEN 'Smith' WHEN 1 THEN 'Johnson' WHEN 2 THEN 'Williams' 
        WHEN 3 THEN 'Brown' WHEN 4 THEN 'Jones' WHEN 5 THEN 'Miller'
        WHEN 6 THEN 'Davis' WHEN 7 THEN 'Garcia' WHEN 8 THEN 'Rodriguez' ELSE 'Wilson'
    END,
    'customer' || n || '@example.com',
    DATE '2019-01-01' + (n * 7 || ' days')::interval,
    CASE 
        WHEN n % 10 = 0 THEN 'gold'
        WHEN n % 5 = 0 THEN 'silver'
        ELSE 'basic'
    END,
    DATE '1980-01-01' + ((n * 37) % 10000 || ' days')::interval
FROM generate_series(1, 200) n;


SELECT * FROM customers;


--  Insert 60 staff members distributed across 30 stores

INSERT INTO staff (staff_id, store_id, first_name, last_name, position, hire_date, salary)
SELECT 
    n,
    (n % 30) + 1, -- Distribute across 30 stores
    CASE (n % 8)
        WHEN 0 THEN 'Robert' WHEN 1 THEN 'Maria' WHEN 2 THEN 'Thomas' 
        WHEN 3 THEN 'Emma' WHEN 4 THEN 'William' WHEN 5 THEN 'Sophia'
        WHEN 6 THEN 'Joseph' ELSE 'Olivia'
    END,
    CASE (n % 8)
        WHEN 0 THEN 'Anderson' WHEN 1 THEN 'Martinez' WHEN 2 THEN 'Taylor' 
        WHEN 3 THEN 'Hernandez' WHEN 4 THEN 'Moore' WHEN 5 THEN 'Clark'
        WHEN 6 THEN 'Lee' ELSE 'Walker'
    END,
    CASE 
        WHEN n % 10 = 0 THEN 'Manager'
        WHEN n % 4 = 0 THEN 'Shift Leader'
        ELSE 'Barista'
    END,
    DATE '2018-01-01' + (n * 20 || ' days')::interval,
    CASE 
        WHEN n % 10 = 0 THEN 45000 + (n * 123) % 10000 -- Manager salary
        WHEN n % 4 = 0 THEN 35000 + (n * 123) % 5000 -- Shift leader
        ELSE 25000 + (n * 123) % 5000 -- Barista
    END
FROM generate_series(1, 60) n;

SELECT * FROM staff;


-- 1. Delete all data and reset sequence
TRUNCATE TABLE transactions RESTART IDENTITY CASCADE;

-- Generate transactions (500 transactions)

INSERT INTO transactions (
    transaction_id, store_id, customer_id, transaction_time,
    total_amount, payment_method, discount_applied
)
SELECT 
    n AS transaction_id,
    (random() * 29 + 1)::INT AS store_id,
    (random() * 199 + 1)::INT AS customer_id,
    NOW() - (random() * INTERVAL '365 days') AS transaction_time,
    ROUND((5 + random() * 45)::numeric, 2) AS total_amount,
    (ARRAY['cash', 'credit', 'mobile'])[(random() * 2)::INT + 1] AS payment_method,
    ROUND((random() * 5)::numeric, 2) AS discount_applied
FROM generate_series(1, 500) AS n;



SELECT * FROM transactions;




-- insert transaction details (1-5 items per transaction)

INSERT INTO transaction_details (
    detail_id, transaction_id, item_id, quantity, unit_price, customization
)
SELECT 
    row_number() OVER () AS detail_id,
    tx_id AS transaction_id,
    (random() * 19 + 1)::INT AS item_id,
    (random() * 2 + 1)::INT AS quantity,
    ROUND((2 + random() * 8)::numeric, 2) AS unit_price,
    (ARRAY['None', 'Extra shot', 'Soy milk', 'No sugar'])[(random() * 3)::INT + 1] AS customization
FROM (
    SELECT n AS tx_id,
           generate_series(1, (random() * 4 + 1)::INT) AS item_line
    FROM generate_series(1, 500) AS n
) AS tx_items;



SELECT * FROM transaction_details;

-- insert review (500)

INSERT INTO reviews (
    review_id, store_id, customer_id, rating, review_text, review_date
)
SELECT 
    n AS review_id,
    (random() * 29 + 1)::INT AS store_id,
    (random() * 199 + 1)::INT AS customer_id,
    (random() * 4 + 1)::INT AS rating,
    'This is a review for transaction #' || n AS review_text,
    NOW() - (random() * INTERVAL '365 days') AS review_date
FROM generate_series(1, 500) AS n;

SELECT * FROM reviews;
