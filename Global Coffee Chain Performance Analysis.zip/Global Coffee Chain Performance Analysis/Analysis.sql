-- Top Performing Countries by Revenue
SELECT c.country_name, SUM(t.total_amount) AS total_revenue
FROM transactions t
JOIN stores s ON t.store_id = s.store_id
JOIN countries c ON s.country_id = c.country_id
GROUP BY c.country_name
ORDER BY total_revenue DESC
LIMIT 5; 


-- Monthly Store Performance

SELECT s.store_id, TO_CHAR(t.transaction_time, 'YYYY-MM') AS month,
       ROUND(SUM(t.total_amount), 2) AS monthly_sales
FROM transactions t
JOIN stores s ON t.store_id = s.store_id
GROUP BY s.store_id, month
ORDER BY s.store_id, month;


-- Most Popular Payment Methods

SELECT payment_method, COUNT(*) AS usage_count
FROM transactions
GROUP BY payment_method
ORDER BY usage_count DESC;


--  Best-Selling Menu Items

SELECT mi.item_name, SUM(td.quantity) AS total_sold
FROM transaction_details td
JOIN menu_items mi ON td.item_id = mi.item_id
GROUP BY mi.item_name
ORDER BY total_sold DESC
LIMIT 5;


--  Peak Transaction Hours

SELECT EXTRACT(HOUR FROM transaction_time) AS hour, COUNT(*) AS total_transactions
FROM transactions
GROUP BY hour
ORDER BY total_transactions DESC;


-- Customer Loyalty Tier Breakdown

SELECT loyalty_tier, COUNT(*) AS customer_count
FROM customers
GROUP BY loyalty_tier
ORDER BY customer_count DESC;


-- Average Review Rating by Store

SELECT s.store_id, ROUND(AVG(r.rating), 2) AS avg_rating
FROM reviews r
JOIN stores s ON r.store_id = s.store_id
GROUP BY s.store_id
ORDER BY avg_rating DESC;


-- Revenue Impact of Promotions (Assuming discount_applied > 0 means promo was used)

SELECT
  CASE WHEN discount_applied > 0 THEN 'Promotion Used' ELSE 'No Promotion' END AS promo_status,
  COUNT(*) AS transaction_count,
  ROUND(SUM(total_amount), 2) AS revenue
FROM transactions
GROUP BY promo_status;


-- Top 10 highest revenue stores

SELECT s.store_id, s.city, c.country_name, 
       SUM(t.total_amount) AS total_revenue
FROM stores s
JOIN countries c ON s.country_id = c.country_id
JOIN transactions t ON s.store_id = t.store_id
GROUP BY s.store_id, s.city, c.country_name
ORDER BY total_revenue DESC
LIMIT 10;

-- Sentiment analysis (simple keyword approach)

SELECT store_id, rating,
       CASE 
           WHEN review_text ILIKE '%excellent%' OR review_text ILIKE '%great%' THEN 'positive'
           WHEN review_text ILIKE '%poor%' OR review_text ILIKE '%bad%' THEN 'negative'
           ELSE 'neutral'
       END AS sentiment,
       COUNT(*) AS review_count
FROM reviews
GROUP BY store_id, rating, sentiment
ORDER BY store_id, rating;

-- Common ground in negative reviews

WITH words AS (
    SELECT store_id, 
           UNNEST(STRING_TO_ARRAY(LOWER(review_text), ' ')) AS word
    FROM reviews
    WHERE rating <= 2
)
SELECT word, COUNT(*) AS frequency
FROM words
WHERE LENGTH(word) > 4  -- ignore short words
  AND word NOT IN (SELECT word FROM common_words)  -- filter out common words
GROUP BY word
ORDER BY frequency DESC
LIMIT 20;


-- Materialized view for daily sales summary

CREATE MATERIALIZED VIEW mv_daily_sales AS
SELECT DATE(transaction_time) AS sale_date,
       store_id,
       COUNT(*) AS transaction_count,
       SUM(total_amount) AS total_revenue,
       SUM(total_amount - discount_applied) AS net_revenue
FROM transactions
GROUP BY DATE(transaction_time), store_id;

Select * from mv_daily_sales;

