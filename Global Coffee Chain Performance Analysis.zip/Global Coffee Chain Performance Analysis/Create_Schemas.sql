-- Countries where the coffee chain operates
CREATE TABLE countries (
    country_id INT PRIMARY KEY,
    country_name VARCHAR(50) NOT NULL,
    continent VARCHAR(20) NOT NULL,
    gdp_per_capita DECIMAL(10,2),
    population INT
);

-- Store locations
CREATE TABLE stores (
    store_id INT PRIMARY KEY,
    country_id INT REFERENCES countries(country_id),
    city VARCHAR(50) NOT NULL,
    address VARCHAR(100),
    opening_date DATE NOT NULL,
    square_footage INT,
    has_drive_thru BOOLEAN,
    is_24_hours BOOLEAN
);

-- Menu items
CREATE TABLE menu_items (
    item_id INT PRIMARY KEY,
    category VARCHAR(30) NOT NULL, -- coffee, tea, food, etc.
    item_name VARCHAR(100) NOT NULL,
    description TEXT,
    base_price DECIMAL(5,2) NOT NULL,
    cost_to_make DECIMAL(5,2) NOT NULL,
    is_seasonal BOOLEAN DEFAULT FALSE
);

-- Customers
CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100),
    join_date DATE,
    loyalty_tier VARCHAR(20), -- basic, silver, gold
    birthday DATE
);

-- Transactions
CREATE TABLE transactions (
    transaction_id INT PRIMARY KEY,
    store_id INT REFERENCES stores(store_id),
    customer_id INT REFERENCES customers(customer_id),
    transaction_time TIMESTAMP NOT NULL,
    total_amount DECIMAL(6,2) NOT NULL,
    payment_method VARCHAR(20) NOT NULL, -- cash, credit, mobile
    discount_applied DECIMAL(5,2) DEFAULT 0
);

-- Transaction details (line items)
CREATE TABLE transaction_details (
    detail_id INT PRIMARY KEY,
    transaction_id INT REFERENCES transactions(transaction_id),
    item_id INT REFERENCES menu_items(item_id),
    quantity INT NOT NULL,
    unit_price DECIMAL(5,2) NOT NULL,
    customization TEXT -- extra shot, milk type, etc.
);

-- Staff information
CREATE TABLE staff (
    staff_id INT PRIMARY KEY,
    store_id INT REFERENCES stores(store_id),
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    position VARCHAR(30) NOT NULL, -- barista, manager, etc.
    hire_date DATE NOT NULL,
    salary DECIMAL(8,2)
);

-- Customer reviews
CREATE TABLE reviews (
    review_id INT PRIMARY KEY,
    store_id INT REFERENCES stores(store_id),
    customer_id INT REFERENCES customers(customer_id),
    rating INT CHECK (rating BETWEEN 1 AND 5),
    review_text TEXT,
    review_date DATE NOT NULL
);

-- Promotions
CREATE TABLE promotions (
    promotion_id INT PRIMARY KEY,
    promotion_name VARCHAR(100) NOT NULL,
    description TEXT,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    discount_percentage DECIMAL(5,2),
    applicable_items VARCHAR(100) -- category or specific items
);

SELECT * FROM countries ;